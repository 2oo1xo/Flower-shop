﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using FinalProject;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Form8 : Form
    {
        EmployeeDetails emp = new EmployeeDetails();

        public Form8()
        {
            InitializeComponent();
            comboBox1.Items.Add("Female");
            comboBox1.Items.Add("Male");
            dataGridView1.DataSource = emp.GetEmployee();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'new_Microsoft_Access_DatabaseDataSet.FlowersShopDatabase' table. You can move, or remove it, as needed.
            this.flowersShopDatabaseTableAdapter.Fill(this.new_Microsoft_Access_DatabaseDataSet.FlowersShopDatabase);

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";


        }

        private void button10_Click(object sender, EventArgs e)
        {
            emp.ID = textBox1.Text;
            emp.FirstName = textBox2.Text;
            emp.LastName = textBox3.Text;
            emp.BD = textBox4.Text;
            emp.Phone = textBox5.Text;
            emp.Username = textBox6.Text;
            emp.Password = textBox7.Text;
            emp.Gender = comboBox1.SelectedItem.ToString();
            

            var success = emp.InsertEmployeeDetails(emp);


            dataGridView1.DataSource = emp.GetEmployee();
            if (success)
            {
               
                this.textBox1.Clear();
                this.textBox2.Clear();
                this.textBox3.Clear();
                this.textBox4.Clear();
                this.textBox5.Clear();
                this.textBox6.Clear();
                this.textBox7.Clear();
               
               
                
                MessageBox.Show("Employee has been added successfully ");

            }

            else
            {
                MessageBox.Show("Error occured, Please try again! ");
            }




        }


        //___________________________________________________________________________________
        
     
        //________________________________________________________________________________


        private void button13_Click(object sender, EventArgs e)
        {

            emp.ID = textBox1.Text;

            var success = emp.DeleteEmployeeDetails(emp);

            if (success)
            {
                this.textBox1.Clear();
                this.textBox2.Clear();
                this.textBox3.Clear();
                this.textBox4.Clear();
                this.textBox5.Clear();
                this.textBox6.Clear();
                this.textBox7.Clear();
                MessageBox.Show("Employee has been Deleted successfully ");
            }

            else
            {
                MessageBox.Show("Error occured, Please try again! ");
            }

        }



//________________________________________________________________________________________


        private void button12_Click(object sender, EventArgs e)
        {

           


            this.flowersShopDatabaseTableAdapter.Update(this.new_Microsoft_Access_DatabaseDataSet.FlowersShopDatabase);
            MessageBox.Show("SQL operation is successful.");
        }






        //________________________________________________________________________________________







        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            var i = e.RowIndex;
            textBox1.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
            textBox6.Text = dataGridView1.Rows[i].Cells[5].Value.ToString();
            textBox7.Text = dataGridView1.Rows[i].Cells[6].Value.ToString();
            comboBox1.Text = dataGridView1.Rows[i].Cells[7].Value.ToString();
            
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 f7 = new Form7();
            f7.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 f7 = new Form7();
            f7.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f3 = new Form3();
            f3.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 f4 = new Form4();
            f4.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 f5 = new Form5();
            f5.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 f6 = new Form6();
            f6.ShowDialog();
        }

      

       
      
    }
}
