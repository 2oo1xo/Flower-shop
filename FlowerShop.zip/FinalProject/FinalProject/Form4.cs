﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.pictureBox1.Image = Image.FromFile(@"C:\Users\Rama\Desktop\FinalProject\1.jpg");
        }

        private void button14_Click(object sender, EventArgs e)
        {
            this.pictureBox1.Image = Image.FromFile(@"C:\Users\Rama\Desktop\FinalProject\2.jpg");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.pictureBox1.Image = Image.FromFile(@"C:\Users\Rama\Desktop\FinalProject\3.jpg");
        }

        private void button16_Click(object sender, EventArgs e)
        {
            this.pictureBox1.Image = Image.FromFile(@"C:\Users\Rama\Desktop\FinalProject\4.jpg");
        }

        private void button17_Click(object sender, EventArgs e)
        {
            this.pictureBox1.Image = Image.FromFile(@"C:\Users\Rama\Desktop\FinalProject\5.jpg");
        }

        private void button18_Click(object sender, EventArgs e)
        {
            this.pictureBox1.Image = Image.FromFile(@"C:\Users\Rama\Desktop\FinalProject\6.jpg");
        }


        //____________________________________________________________________________________________________________


        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f3 = new Form3();
            f3.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
          
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                MessageBox.Show("You are selected Muslim's Occasions ");
                this.Hide();
                Form5 f5 = new Form5();
                f5.ShowDialog();
                return;
            }
            else if (radioButton2.Checked == true)
            {
                MessageBox.Show("You are selected NewBorn Occasion ");
                this.Hide();
                Form5 f5 = new Form5();
                f5.ShowDialog();
                return;
            }
            else if (radioButton3.Checked == true)
            {
                MessageBox.Show("You are selected Graduations Occasion ");
                this.Hide();
                Form5 f5 = new Form5();
                f5.ShowDialog();
                return;
            }
            else if (radioButton4.Checked == true)
            {
                MessageBox.Show("You are selected Wedding Occasion ");
                this.Hide();
                Form5 f5 = new Form5();
                f5.ShowDialog();
                return;
            }
            else if (radioButton5.Checked == true)
            {
                MessageBox.Show("You are selected Mother's day  Occasion ");
                this.Hide();
                Form5 f5 = new Form5();
                f5.ShowDialog();
                return;
            }
            else
            {
                MessageBox.Show("You are selected Birthday  NewYear  Anoter Occasion  !! ");
                this.Hide();
                Form5 f5 = new Form5();
                f5.ShowDialog();
                return;


            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 f6 = new Form6();
            f6.ShowDialog();
        }


        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 f7 = new Form7();
            f7.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 f8 = new Form8();
            f8.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 f9 = new Form8();
            f9.ShowDialog();
        }



        private void button9_Click_1(object sender, EventArgs e)
        {

            this.Hide();
            Form3 f3 = new Form3();
            f3.ShowDialog();

        }

        private void button11_Click(object sender, EventArgs e)
        {



            if (radioButton1.Checked == true)
            {
                MessageBox.Show("You are selected Muslim's Occasions ");
                this.Hide();
                Form5 f5 = new Form5();
                f5.ShowDialog();
                return;
            }
            else if (radioButton2.Checked == true)
            {
                MessageBox.Show("You are selected NewBorn Occasion ");
                this.Hide();
                Form5 f5 = new Form5();
                f5.ShowDialog();
                return;
            }
            else if (radioButton3.Checked == true)
            {
                MessageBox.Show("You are selected Graduations Occasion ");
                this.Hide();
                Form5 f5 = new Form5();
                f5.ShowDialog();
                return;
            }
            else if (radioButton4.Checked == true)
            {
                MessageBox.Show("You are selected Wedding Occasion ");
                this.Hide();
                Form5 f5 = new Form5();
                f5.ShowDialog();
                return;
            }
            else if (radioButton5.Checked == true)
            {
                MessageBox.Show("You are selected Mother's day  Occasion ");
                this.Hide();
                Form5 f5 = new Form5();
                f5.ShowDialog();
                return;
            }
            else
            {
                MessageBox.Show("You are selected Birthday  NewYear  Anoter Occasion  !! ");
                this.Hide();
                Form5 f5 = new Form5();
                f5.ShowDialog();
                return;
            }




        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        
    }

}
