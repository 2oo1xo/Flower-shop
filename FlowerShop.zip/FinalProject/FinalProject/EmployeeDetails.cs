﻿using System;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text;

namespace FinalProject
{
    class EmployeeDetails
    {
        private static string myconn = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Rama\Desktop\FinalProject\New Microsoft Access Database.accdb";
        public string ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string BD { get; set; }
        public string Phone { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Gender { get; set; }



        private const string SelectQuery = @"Select * from FlowersShopDatabase";
        private const string InsertQuery = @"Insert Into FlowersShopDatabase  Values (@ID , @FirstName , @LastName , @BD , @Phone , @Username , @Password , @Gender)";


        private const string UpdateQuery = @"Update FlowersShopDatabase set  ID=@ID  , FirstName=@FirstName , LastName=@LastName , BD=@BD ,
Phone=@Phone , Username=@Username , Password=@Password , Gender=@Gender  ";

        private const string DeleteQuery = @" Delete from FlowersShopDatabase where ID=@ID ";



        //_____________________________________________________________________________________________

        public bool InsertEmployeeDetails(EmployeeDetails emp)
        {
            int rows;
            using (OleDbConnection con = new OleDbConnection(myconn))
            {
                con.Open();
                using (OleDbCommand com = new OleDbCommand(InsertQuery, con))
                {
                    com.Parameters.AddWithValue("@ID" , emp.ID);
                    com.Parameters.AddWithValue("@FirstName", emp.FirstName);
                    com.Parameters.AddWithValue("@LastName", emp.LastName);
                    com.Parameters.AddWithValue("@BD", emp.BD);
                    com.Parameters.AddWithValue("@Phone", emp.Phone);
                    com.Parameters.AddWithValue("@Username", emp.Username);
                    com.Parameters.AddWithValue("@Password", emp.Password);
                    com.Parameters.AddWithValue("@Gender", emp.Gender);
                    rows = com.ExecuteNonQuery();

                }
            }

            return (rows > 0) ? true : false;
 
        }





        public bool UpdateEmployeeDetails(EmployeeDetails emp)
        {
            int rows;
            using (OleDbConnection con = new OleDbConnection(myconn))
            {
                con.Open();
                using (OleDbCommand com = new OleDbCommand(UpdateQuery , con))
                {
                    com.Parameters.AddWithValue("@ID", emp.ID);
                    com.Parameters.AddWithValue("@FirstName", emp.FirstName);
                    com.Parameters.AddWithValue("@LastName", emp.LastName);
                    com.Parameters.AddWithValue("@BD", emp.BD);
                    com.Parameters.AddWithValue("@Phone", emp.Phone);
                    com.Parameters.AddWithValue("@Username", emp.Username);
                    com.Parameters.AddWithValue("@Password", emp.Password);
                    com.Parameters.AddWithValue("@Gender", emp.Gender);
                    rows = com.ExecuteNonQuery();
                }
            }

            return (rows > 0) ? true : false; 

            
        }

        //___________________________________________________________________


        public bool DeleteEmployeeDetails(EmployeeDetails emp)
        {
            int rows;
            using (OleDbConnection con = new OleDbConnection(myconn))
            {
                 con.Open();
                 using (OleDbCommand com = new OleDbCommand(DeleteQuery, con))
                 {
                     com.Parameters.AddWithValue("@ID", emp.ID);
                     rows = com.ExecuteNonQuery();
                 }
            }
            return (rows > 0) ? true : false; 
        }

        //___________________________________________________________________________

        public DataTable GetEmployee()
        {
            var datatable = new DataTable();
            using (OleDbConnection con = new OleDbConnection(myconn))
            {
                con.Open();
                using (OleDbCommand com = new OleDbCommand(SelectQuery, con))
                {
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(com))
                    {
                        adapter.Fill(datatable);
                    }
                }
            }
            return datatable;
        }

    }
}
