﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
                        

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 f8 = new Form8();
            f8.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 f9 = new Form8();
            f9.ShowDialog();
        }

     
        private void button11_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 f6 = new Form6();
            f6.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f3 = new Form3();
            f3.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 f4 = new Form4();
            f4.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void button6_Click(object sender, EventArgs e)
        {

            if (radioButton1.Checked == true)
            {
                MessageBox.Show("You are selected Mix chocolate  ");
                this.Hide();
                Form6 f6 = new Form6();
                f6.ShowDialog();

                return;
            }
            else if (radioButton3.Checked == true)
            {
                MessageBox.Show("You are selected Mix Mini Chocolate  ");
                this.Hide();
                Form6 f6 = new Form6();
                f6.ShowDialog();
                return;
            }
            else if (radioButton2.Checked == true)
            {
                MessageBox.Show("You are selected " + numericUpDown1.Value.ToString() + " of Ferrero Rocher ");
                this.Hide();
                Form6 f6 = new Form6();
                f6.ShowDialog();
                return;
            }

            else
            {
                MessageBox.Show("You are selected None ");
                this.Hide();
                Form6 f6 = new Form6();
                f6.ShowDialog();
                return;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 f7 = new Form7();
            f7.ShowDialog();
        }

       


      
    }
}
