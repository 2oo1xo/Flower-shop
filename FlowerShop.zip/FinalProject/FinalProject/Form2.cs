﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            label4.Text = "0";
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true) 
            {

                MessageBox.Show(" The Flower you selcet: " + numericUpDown1.Value.ToString() + " " + checkBox1.Text);
            }

            if (checkBox2.Checked == true) 
            {

                MessageBox.Show(" The numper Flower you selcet: " + numericUpDown2.Value.ToString() + " " + checkBox2.Text);
            }
            if (checkBox3.Checked == true)
            {

                MessageBox.Show(" The numper Flower you selcet: " + numericUpDown3.Value.ToString() + " " + checkBox3.Text);
            }
            if (checkBox4.Checked == true)
            {

                MessageBox.Show(" The numper Flower you selcet: " + numericUpDown4.Value.ToString() + " " + checkBox4.Text);
            }
            if (checkBox5.Checked == true)
            {

                MessageBox.Show(" The numper Flower you selcet: " + numericUpDown5.Value.ToString() + " " + checkBox5.Text);
            }
            if (checkBox6.Checked == true)
            {

                MessageBox.Show(" The numper Flower you selcet: " + numericUpDown6.Value.ToString() + " " + checkBox6.Text);
            }
            

      


           // MessageBox.Show("You are selected " + label4.Text + " of Flowers ");
            

            this.Hide();
            Form3 f3 = new Form3();
            f3.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            this.Hide();
            Form4 f4 = new Form4();
            f4.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 f5 = new Form5();
            f5.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 f6 = new Form6();
            f6.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 f7 = new Form7();
            f7.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 f8 = new Form8();
            f8.ShowDialog();
        }


        //_______________________________________________________________________________________________________


        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            decimal d = numericUpDown5.Value + numericUpDown3.Value + numericUpDown1.Value + numericUpDown2.Value + numericUpDown4.Value + numericUpDown6.Value;
            label4.Text = d.ToString();
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            decimal d = numericUpDown5.Value + numericUpDown3.Value + numericUpDown1.Value + numericUpDown2.Value + numericUpDown4.Value + numericUpDown6.Value;
            label4.Text = d.ToString();
        }

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            decimal d = numericUpDown5.Value + numericUpDown3.Value + numericUpDown1.Value + numericUpDown2.Value + numericUpDown4.Value + numericUpDown6.Value;
            label4.Text = d.ToString();
        }

        private void numericUpDown4_ValueChanged(object sender, EventArgs e)
        {
            decimal d = numericUpDown5.Value + numericUpDown3.Value + numericUpDown1.Value + numericUpDown2.Value + numericUpDown4.Value + numericUpDown6.Value;
            label4.Text = d.ToString();
        }

        private void numericUpDown5_ValueChanged(object sender, EventArgs e)
        {
            decimal d = numericUpDown5.Value + numericUpDown3.Value + numericUpDown1.Value + numericUpDown2.Value + numericUpDown4.Value + numericUpDown6.Value;
            label4.Text = d.ToString();
        }

        private void numericUpDown6_ValueChanged(object sender, EventArgs e)
        {
            decimal d = numericUpDown5.Value + numericUpDown3.Value + numericUpDown1.Value + numericUpDown2.Value + numericUpDown4.Value + numericUpDown6.Value;
            label4.Text = d.ToString();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)

        {
            if (checkBox1.Checked == true)
            {

                MessageBox.Show(" The Flower you selcet: " + numericUpDown1.Value.ToString() + " " + checkBox1.Text);
            }

            if (checkBox2.Checked == true)
            {

                MessageBox.Show(" The numper Flower you selcet: " + numericUpDown2.Value.ToString() + " " + checkBox2.Text);
            }
            if (checkBox3.Checked == true)
            {

                MessageBox.Show(" The numper Flower you selcet: " + numericUpDown3.Value.ToString() + " " + checkBox3.Text);
            }
            if (checkBox4.Checked == true)
            {

                MessageBox.Show(" The numper Flower you selcet: " + numericUpDown4.Value.ToString() + " " + checkBox4.Text);
            }
            if (checkBox5.Checked == true)
            {

                MessageBox.Show(" The numper Flower you selcet: " + numericUpDown5.Value.ToString() + " " + checkBox5.Text);
            }
            if (checkBox6.Checked == true)
            {

                MessageBox.Show(" The numper Flower you selcet: " + numericUpDown6.Value.ToString() + " " + checkBox6.Text);
            }
            


            this.Hide();
            Form3 f3 = new Form3();
            f3.ShowDialog();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        

      //_______________________________________________________________________________________________________________________


        
    }
}
