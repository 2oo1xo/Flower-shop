﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Form1 : Form
    {
        private OleDbConnection connection = new OleDbConnection();
        public Form1()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Rama\Desktop\FinalProject\New Microsoft Access Database.accdb;Persist Security Info=False;";
        }

       

        private void Form2_Load(object sender, EventArgs e)
        {
            try
            {

                
                connection.Open();
                label1.Text = "Connection Successful";
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }

        }

        

        private void button3_Click_1(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            command.CommandText = "Select * from FlowersShopDatabase where Username= '" + textBox1.Text + "' and Password='" + textBox2.Text + "' ";
            OleDbDataReader reader = command.ExecuteReader();
            int count = 0;
            while (reader.Read())
            {
                count = count + 1;
            }
            if (count == 1)
            {
                MessageBox.Show("Username and password is correct");
                this.Hide();
                Form2 f3 = new Form2();
                f3.ShowDialog();
            }
            else if (count > 1)
            {
                MessageBox.Show("Duplicate Username and password is correct");
            }
            else
            {
                MessageBox.Show("Username and password is not correct");
            }




            connection.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

       
    }
}
