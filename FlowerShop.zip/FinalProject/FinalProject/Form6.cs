﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }


        private void button8_Click(object sender, EventArgs e)
        {
            

            this.Hide();
            Form8 f8 = new Form8();
            f8.ShowDialog();


        }

        private void treeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            //_______________________________Northern region_______________________________________________

            if (e.Node.Name == "Node3")
            {
                textBox1.Text = "Irbid ";
            }
            else if (e.Node.Name == "Node4")
            {
                textBox1.Text = "Mafraq	";
            }
            else if (e.Node.Name == "Node5")
            {
                textBox1.Text = "Jerash ";
            }
            else if (e.Node.Name == "Node6")
            {
                textBox1.Text = "Ajloun	";
            }

            //_______________________________Central region_______________________________________________

            else if (e.Node.Name == "Node7")
            {
                textBox1.Text = "Amman ";
            }
            else if (e.Node.Name == "Node8")
            {
                textBox1.Text = "Zarqa ";
            }
            else if (e.Node.Name == "Node9")
            {
                textBox1.Text = "Balqa ";
            }
            else if (e.Node.Name == "Node10")
            {
                textBox1.Text = "Madaba	";
            }

            //_______________________________Southern region_______________________________________________

            else if (e.Node.Name == "Node11")
            {
                textBox1.Text = "Karak ";
            }
            else if (e.Node.Name == "Node12")
            {
                textBox1.Text = "Aqaba ";
            }
            else if (e.Node.Name == "Node13")
            {
                textBox1.Text = "Ma'an ";
            }
           
            else
            {
                textBox1.Text = "Tafila ";
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f3 = new Form3();
            f3.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 f4 = new Form4();
            f4.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 f5 = new Form5();
            f5.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
        }

        private void button13_Click(object sender, EventArgs e)
        {


            DateTime idate;
            idate = dateTimePicker1.Value;
            MessageBox.Show("Selected Date and Time: " + idate + " Lcation: " + textBox1.Text);

            this.Hide();
            Form7 f7 = new Form7();
            f7.ShowDialog();
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form5 f5 = new Form5();
            f5.ShowDialog();
        }

        private void button11_Click(object sender, EventArgs e)
        {


            DateTime idate;
            idate = dateTimePicker1.Value;
            MessageBox.Show("Selected Date and Time: " + idate + " Lcation: " + textBox1.Text);

            this.Hide();
            Form7 f7 = new Form7();
            f7.ShowDialog();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = " yyyy-MM-dd   tt ss:mm:hh  ";
        }

      
        
    }
}
